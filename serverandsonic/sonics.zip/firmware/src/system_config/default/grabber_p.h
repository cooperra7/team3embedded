/* 
 * File:   grabber_p.h
 * Author: theheavyhorse
 *
 * Created on October 12, 2016, 11:19 PM
 */

#ifndef GRABBER_P_H
#define	GRABBER_P_H

#ifdef	__cplusplus
extern "C" {
#endif

    typedef struct values
    {
        unsigned char sensor;
        uint16_t val1;
        uint16_t val2;
    }VALUES_t;
    
    void Qinit ();
    
    void QSendFromISR (VALUES_t tmrvals);
    
    VALUES_t QReceive ();
    
    int whichOC ();


#ifdef	__cplusplus
}
#endif

#endif	/* GRABBER_P_H */

