/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    grabber.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "grabber.h"
#include "grabber_p.h"
#include "datastructures.h"
#include "data_pub.h"
#include "debug.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

GRABBER_DATA grabberData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void GRABBER_Initialize ( void )

  Remarks:
    See prototype in grabber.h.
 */

 int OCenabled;

void GRABBER_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    grabberData.state = GRABBER_STATE_INIT;

    
    PLIB_PORTS_DirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_E, 0x00FF);
//    PLIB_PORTS_DirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_A, 0x00EC);
//    PLIB_PORTS_DirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_G, 0x7000);
    PLIB_PORTS_DirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_D, 0x2293);
//    PLIB_PORTS_DirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_C, 0x6010);
    
    DRV_TMR0_Initialize (); /* Initialize the driver timer */
    DRV_OC0_Initialize ();
    DRV_OC1_Initialize ();
    DRV_OC2_Initialize ();
    PLIB_PORTS_Write (PORTS_ID_0, PORT_CHANNEL_E, 0x00FF & 0x43);
    
    Qinit(); /* Initialize the Queue */
    OCenabled = 0;

    PLIB_PORTS_PinDirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_D, 3);
    PLIB_PORTS_PinDirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_D, 4);
    PLIB_PORTS_PinDirectionInputSet (PORTS_ID_0, PORT_CHANNEL_D, 10);
    PLIB_PORTS_PinDirectionInputSet (PORTS_ID_0, PORT_CHANNEL_D, 8);

    PLIB_PORTS_PinDirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_C, 1);
    PLIB_PORTS_PinDirectionOutputSet (PORTS_ID_0, PORT_CHANNEL_A, 3);
}


/******************************************************************************
  Function:
    void GRABBER_Tasks ( void )

  Remarks:
    See prototype in grabber.h.
 */

void GRABBER_Tasks ( void )
{
    DRV_TMR0_Start ();
    DRV_IC0_Start ();
    DRV_IC1_Start ();
    DRV_IC2_Start ();
//    DRV_TMR1_Start();
//    DRV_OC0_Start ();
    
    RESPONSE_t resp;
    resp.sensorval.type = SENSORVAL;
    resp.sensorval.ID = 12;
    resp.sensorval.source = GRABBER;
    resp.sensorval.dest = GRABBER;
    resp.sensorval.left = 0;
    resp.sensorval.right = 0;
    resp.sensorval.center = 0;
    
    int count = 0;
    int leftAvg = 0;
    int centerAvg = 0;
    int rightAvg = 0;
    
    bool center = false;
    bool left = false;
    bool right = false;
    
    while (1)
    {
        VALUES_t vals;
        dbgOutputLoc(0x61);
        vals = QReceive();
        int diff = vals.val1 - vals.val2;
        diff = abs(diff);
        int step = diff * 8;
        int cm = step / 58;

        if (vals.sensor == 0x00) {
            leftAvg = cm;
//            resp.sensorval.left = vals.val1;
//            resp.sensorval.right = vals.val2;
//            dataQSendResponse (resp);
        }
        else if (vals.sensor == 0x11) {
            rightAvg = cm;
        }
        else if (vals.sensor == 0x22) {
            centerAvg = cm;
        }
        if (count < 5) {
            ;
        }
        resp.sensorval.left = leftAvg;
        resp.sensorval.right = rightAvg;
        resp.sensorval.center = centerAvg;
        int center = leftAvg - rightAvg;
        if (center >= -1 && center <= 1) {
            PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_C, 1, 1);
        }
        else {
            PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_C, 1, 0);
        }
        dataQSendResponse(resp);
/*        else {
            count = 0;
            resp.sensorval.left = diff;
            leftAvg = 0;
            resp.sensorval.right = cm;
            rightAvg = 0;
            int center = resp.sensorval.left - resp.sensorval.right;
            if (center >= -1 && center <= 1) {
                PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_C, 1, 1);
            }
            else {
                PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_C, 1, 0);
            }
            dataQSendResponse (resp);
        }*/
        dbgOutputLoc(0xDD);
    }
}

QueueHandle_t Q;


void Qinit ()
{
    Q = xQueueCreate (1, sizeof (VALUES_t));
}

void QSendFromISR (VALUES_t tmrvals)
{
    /* Check for whether the task needs to do a context switch */
    BaseType_t conSwitch;
    conSwitch = pdFALSE;
    
    /* Send to the Queue from an ISR */
    if ((xQueueOverwriteFromISR (Q, &tmrvals, &conSwitch)) == errQUEUE_FULL) {
        PLIB_PORTS_Write (PORTS_ID_0, PORT_CHANNEL_E, 0x00FA);
//        xQueueReset(Q);
    }
    
    /* Switch if needed */
    portEND_SWITCHING_ISR(conSwitch);
}

VALUES_t QReceive ()
{
    VALUES_t ret;
    xQueueReceive (Q, &ret, portMAX_DELAY);
    return ret;
}

int whichOC ()
{
    if (OCenabled == 0) {
        OCenabled = 1;
        dbgOutputLoc (0xEA);
        return 0;
    }
    else if (OCenabled == 1) {
        dbgOutputLoc (0xEB);
        OCenabled = 2;
        return 1;
    }
    else if (OCenabled == 2) {
        OCenabled = 0;
        return 2;
    }
    else if (OCenabled == 3) {
        OCenabled = 0;
        return 3;
    }
    OCenabled = 0;
    return 2;
}